# SUBHAM CHSE 2027 Android app source

This is an Android Studio project wrapping the existing SUBHAM CHSE 2027 study planner in a WebView and adding native Android scheduled notifications.

## Build an APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `SUBHAM_CHSE_2027_Android` folder.
4. Allow Android Studio to install the required Android SDK/build tools and sync Gradle.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build completes, use **Locate** in the notification to find the APK. Normally it is at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your phone and open it. If Android asks, allow installing apps from that file source.

## Alarms
- Add reminders inside the app's **Study alarms** section.
- Tap **Enable Android alarms** and allow **Alarms & reminders** / exact-alarm access if Android offers it.
- Allow notifications for **SUBHAM CHSE 2027** in Android settings.
- The app schedules a daily native alarm and re-schedules it after reboot. Android battery-saving policies and device settings can still affect delivery; test an alarm a few minutes ahead before relying on it.

## Notes
- This ZIP is the Android Studio project source, **not a compiled APK**. A compiled APK cannot be claimed until Android Studio/Gradle builds it successfully.
- The app includes the study plan, chapter tracker, focus timer, YouTube search/embed and progress export from the original HTML.
- The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35 and Java/Kotlin toolchains supplied by Android Studio.
