plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.subham.chse2027"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.subham.chse2027"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
