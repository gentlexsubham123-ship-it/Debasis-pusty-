package com.subham.chse2027

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AlarmBridge(this), "AndroidAlarm")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
        requestNotificationPermissionIfNeeded()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                StudyAlarmReceiver.CHANNEL_ID,
                "Study reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Daily reminders for your SUBHAM CHSE 2027 study plan"
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}

class AlarmBridge(private val context: Context) {
    @JavascriptInterface
    fun scheduleDailyAlarm(idText: String, time: String, subject: String) {
        val id = idText.toIntOrNull() ?: idText.hashCode()
        val parts = time.split(":")
        if (parts.size != 2) return
        val hour = parts[0].toIntOrNull() ?: return
        val minute = parts[1].toIntOrNull() ?: return
        val prefs = context.getSharedPreferences(StudyAlarmReceiver.PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString("alarm_$id", "$hour|$minute|$subject").apply()
        StudyAlarmReceiver.schedule(context, id, hour, minute, subject)
    }

    @JavascriptInterface
    fun cancelAlarm(idText: String) {
        val id = idText.toIntOrNull() ?: idText.hashCode()
        context.getSharedPreferences(StudyAlarmReceiver.PREFS, Context.MODE_PRIVATE)
            .edit().remove("alarm_$id").apply()
        val intent = StudyAlarmReceiver.pendingIntent(context, id, "", false)
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (intent != null) manager.cancel(intent)
    }

    @JavascriptInterface
    fun requestNotificationPermission() {
        if (context is Activity && Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            context.runOnUiThread {
                context.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
            }
        }
    }

    @JavascriptInterface
    fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!manager.canScheduleExactAlarms()) {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } else {
                Toast.makeText(context, "Exact alarms are already allowed.", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Exact alarms are supported on this Android version.", Toast.LENGTH_SHORT).show()
        }
    }
}
