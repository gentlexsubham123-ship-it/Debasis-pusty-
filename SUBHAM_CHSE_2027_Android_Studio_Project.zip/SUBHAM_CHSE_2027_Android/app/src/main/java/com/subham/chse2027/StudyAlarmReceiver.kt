package com.subham.chse2027

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar

class StudyAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("alarm_id", 0)
        val subject = intent.getStringExtra("subject") ?: "Study"
        val title = "SUBHAM CHSE 2027"
        val body = "Time to study $subject. Your next step starts now!"
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(context).notify(id, notification) } catch (_: SecurityException) {}
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString("alarm_$id", null) ?: return
        val parts = raw.split("|", limit = 3)
        if (parts.size == 3) {
            val hour = parts[0].toIntOrNull() ?: return
            val minute = parts[1].toIntOrNull() ?: return
            schedule(context, id, hour, minute, parts[2])
        }
    }

    companion object {
        const val CHANNEL_ID = "subham_study_reminders"
        const val PREFS = "subham_native_alarms"

        fun pendingIntent(context: Context, id: Int, subject: String, create: Boolean = true): PendingIntent? {
            val intent = Intent(context, StudyAlarmReceiver::class.java)
                .putExtra("alarm_id", id)
                .putExtra("subject", subject)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            return if (create) PendingIntent.getBroadcast(context, id, intent, flags)
            else PendingIntent.getBroadcast(context, id, intent, flags or PendingIntent.FLAG_NO_CREATE)
        }

        fun schedule(context: Context, id: Int, hour: Int, minute: Int, subject: String) {
            val now = Calendar.getInstance()
            val next = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (!after(now)) add(Calendar.DAY_OF_YEAR, 1)
            }
            val pi = pendingIntent(context, id, subject) ?: return
            val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
            } else {
                if (Build.VERSION.SDK_INT >= 23)
                    manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
                else
                    manager.setExact(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
            }
        }

        fun rescheduleAll(context: Context) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).all
            prefs.forEach { (key, value) ->
                if (key.startsWith("alarm_") && value is String) {
                    val id = key.removePrefix("alarm_").toIntOrNull() ?: return@forEach
                    val parts = value.split("|", limit = 3)
                    if (parts.size == 3) {
                        val hour = parts[0].toIntOrNull() ?: return@forEach
                        val minute = parts[1].toIntOrNull() ?: return@forEach
                        schedule(context, id, hour, minute, parts[2])
                    }
                }
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        StudyAlarmReceiver.rescheduleAll(context)
    }
}
